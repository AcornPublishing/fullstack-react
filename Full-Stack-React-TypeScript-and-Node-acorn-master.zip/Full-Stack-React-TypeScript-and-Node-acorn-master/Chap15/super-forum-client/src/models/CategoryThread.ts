export default class CategoryThread {
  constructor(
    public threadId: string,
    public categoryName: string,
    public title: string
  ) {}
}
