import React from "react";

const ScreenB = () => {
  return <div>ScreenB</div>;
};

export default ScreenB;
