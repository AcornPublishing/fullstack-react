import React from "react";

const ScreenA = () => {
  return <div>ScreenA</div>;
};

export default ScreenA;
