// let a = 5;
// let b = '6';
// console.log(a + b);
var a = 5;
var b = 6;
console.log(a + b);
