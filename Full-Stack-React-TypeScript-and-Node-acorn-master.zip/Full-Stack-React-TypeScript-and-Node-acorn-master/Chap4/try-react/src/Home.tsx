import React, { FC } from "react";

const Home: FC = () => {
  return <div>Hello World! Home</div>;
};

export default Home;
