export default class CategoryThread {
  constructor(
    public threadId: string,
    public category: string,
    public title: string
  ) {}
}
