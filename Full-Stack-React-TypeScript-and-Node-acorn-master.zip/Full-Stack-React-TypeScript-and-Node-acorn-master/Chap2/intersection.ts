let obj: { name: string } & { age: number } = {
    name: 'tom',
    age: 25
}
console.log(obj);
