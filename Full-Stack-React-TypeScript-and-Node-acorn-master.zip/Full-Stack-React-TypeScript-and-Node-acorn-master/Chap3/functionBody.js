if (true) {
    var val1 = 1;
}
function go() {
    var val2 = 2;
}
console.log(val1);
//console.log(val2);
