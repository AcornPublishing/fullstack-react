// 1
console.log("Let's begin.");

// 2
setTimeout(() => {
    console.log("I waited and am done now.");
}, 3000);

// 3
console.log("Did I finish yet?");